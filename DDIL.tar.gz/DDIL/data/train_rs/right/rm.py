import sys
import os
for line in sys.stdin:
    os.system('rm -rf ' + line.strip())
