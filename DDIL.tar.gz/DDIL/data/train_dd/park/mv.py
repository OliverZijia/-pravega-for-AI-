import sys
import os
for line in sys.stdin:
    os.system('cp ../../train/park/' + line.strip() + ' .')
