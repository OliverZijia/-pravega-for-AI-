#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
This script loads a pre-trained model (for best results use pre-trained weights for classification block)
and classifies American Sign Language finger spelling
"""
import tensorflow as tf
import string
import cv2
import time
import argparse
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.python.keras import backend as K
import sys
from  tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.python.keras.utils.generic_utils import custom_object_scope
import os
import datetime
from sklearn import metrics
ap = argparse.ArgumentParser()

ap.add_argument("-t", "--test", required=True,
                help="path to the test image directory")
ap.add_argument("-m", "--model", required=True,
                help="path to the  model")
ap.add_argument("-c", "--class_mode", required=True,
                help="class mode")
args = vars(ap.parse_args())
args = vars(ap.parse_args())

model_path = args['model']
test_path = args['test']
class_mode = args['class_mode']
metric = 'AUC'
loss = tf.keras.losses.binary_crossentropy
if class_mode == 'categorical':
    metric = 'accuracy'
    loss = tf.keras.losses.categorical_crossentropy,
def relu6(x):
    return K.relu(x, max_value = 6)

with custom_object_scope({'relu6': relu6}):
    test_datagen = ImageDataGenerator()
    
    test_generator = test_datagen.flow_from_directory(
            test_path,
            target_size = (32, 32),
            batch_size = 1,
            class_mode = class_mode,
            color_mode = 'rgb',
            shuffle = False
            )
    validation_steps = int(test_generator.samples)
    
    if model_path.endswith('.h5'):
        my_model = load_model(model_path)  
        my_model.summary
        my_model.compile(
            loss=loss,
            optimizer='adam',
            metrics=[metric]
            )
        starttime = datetime.datetime.now()
        total_seen = 0
        num_correct = 0
        probs = []
        for i in range(0, test_generator.__len__()):
            img = test_generator.__getitem__(i)[0]
            label = test_generator.__getitem__(i)[1]
            inp = img.reshape((1, 32, 32, 3))
            total_seen += 1
            predictions = my_model.predict(img)
            probs.append(predictions[0][0])
            if np.argmax(predictions) == np.argmax(label):
                num_correct += 1
        endtime = datetime.datetime.now()
        if class_mode == 'categorical':
            print((1.0 * num_correct) / total_seen)
        else:
            print(metrics.roc_auc_score(test_generator.labels, probs))
        print((endtime - starttime).seconds)
    elif model_path.endswith('.tflite'):
        interpreter = tf.lite.Interpreter(model_path = model_path)
        interpreter.allocate_tensors()
        input_index = interpreter.get_input_details()[0]["index"]
        output_index = interpreter.get_output_details()[0]["index"]
        total_seen = 0
        num_correct = 0
        probs = []
        starttime = datetime.datetime.now()
        for i in range(0, test_generator.__len__()):
            img = test_generator.__getitem__(i)[0]
            label = test_generator.__getitem__(i)[1]
            inp = img.reshape((1, 32, 32, 3))
            total_seen += 1
            interpreter.set_tensor(input_index, inp)
            interpreter.invoke()
            predictions = interpreter.get_tensor(output_index)
            probs.append(predictions[0][0])
            if np.argmax(predictions) == np.argmax(label):
                num_correct += 1
        if class_mode == 'categorical':
            print((1.0 * num_correct) / total_seen)
        else:
            print(metrics.roc_auc_score(test_generator.labels, probs))
        endtime = datetime.datetime.now()
        print((endtime - starttime).seconds)


