import numpy as np
import tensorflow as tf
import sys
import os 
import argparse
from tensorflow.python.keras.utils.generic_utils import custom_object_scope
from tensorflow.python.keras import backend as K
from tensorflow.keras.preprocessing.image import ImageDataGenerator
tf.compat.v1.enable_eager_execution()

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

ap = argparse.ArgumentParser()
ap.add_argument("-m", "--model", required=True,
                help="path to the pruned model")

args = vars(ap.parse_args())
model_path = args['model']

def relu6(x):
    return K.relu(x, max_value = 6)

with custom_object_scope({'relu6': relu6}):
    loaded_model = tf.keras.models.load_model(model_path)
    tflite_model_file = model_path + ".tflite"
    converter = tf.lite.TFLiteConverter.from_keras_model(loaded_model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT] 
    converter.target_spec.supported_types = [tf.float16] 
    tflite_model = converter.convert()
    with open(tflite_model_file, "wb") as f:
        f.write(tflite_model)
