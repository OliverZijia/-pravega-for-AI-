#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
TRANSFER LEARNING
This script loads pre-trained deep neural network models included in Keras with a custom classification block,
and trains the new model.
"""
import os

from keras.applications.densenet import DenseNet121
from keras.applications.resnet50 import ResNet50
from keras.applications.inception_v3 import InceptionV3
from keras.applications.xception import Xception
from keras.applications.mobilenet import MobileNet

from keras.layers import Flatten, Dense, Input, Dropout, GlobalAveragePooling2D

from keras.models import Sequential, Model, load_model
from keras.callbacks import ModelCheckpoint, Callback
from keras.preprocessing.image import ImageDataGenerator
from keras.optimizers import Adadelta, Adagrad, Adam, Adamax, Nadam
import numpy as np
import argparse
from keras.callbacks import ReduceLROnPlateau
from keras import backend as K
import tensorflow as tf

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-t", "--train", required=True,
                help="path to the train image directory")
ap.add_argument("-test", "--test", required=False,
                help="path to the test image directory")
ap.add_argument("-m", "--model",
                type=str, default="dense",
                help="name of pre-trained network to use")
ap.add_argument("-e", "--epochs",
                type=int, default=30,
                help="number of epochs")
ap.add_argument("-b", "--batch_size",
                type=int, default=32,
                help="batch size")
ap.add_argument("-o", "--output_num",
                type=str, default="1",
                help="output number of the neural network")

args = vars(ap.parse_args())

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

batch_size = args['batch_size']
output_num = int(args['output_num'])
class_mode = 'binary'
validation_metric = 'val_auc'
training_metric = 'AUC'

if output_num > 1:
    class_mode = 'categorical'
    validation_metric = 'val_accuracy'
    training_metric = 'accuracy'
loss = class_mode + '_crossentropy'

# define a dictionary that maps model names to their classes
# Map model names to classes
MODELS = {
    "dense": DenseNet121,
    "inception": InceptionV3,
    "xception": Xception,
    "resnet": ResNet50,
    "mobilenet": MobileNet
}

shape = (32, 32, 3)
target_size = (32, 32)

# load model
print("[INFO] loading {}...".format(args["model"]))
Network = MODELS[args["model"]]
feat_model = Network(
                include_top = False,
                weights = None,
                input_tensor = Input(shape = shape)
                )
print("[INFO] model loaded.")

# freeze base model layers
for layer in feat_model.layers:
    layer.trainable = True

# Classification block
print("[INFO] creating classification block")
feat_repr = GlobalAveragePooling2D()(feat_model.output)
output = Dense(1, activation='sigmoid')(feat_repr)
if output_num > 1:
    output = Dense(output_num, activation='softmax')(feat_repr)

my_model = Model(inputs = feat_model.input,
                 outputs = output)

filepath = "best_" + args["model"] + ".h5"

# compile model
print("[INFO] compiling model")
my_model.compile(optimizer=Adam(0.1),
                 loss = loss,
                 metrics=[training_metric])
# TRAINING
# Model Checkpoint
save_snapshots = ModelCheckpoint(
                                 filepath,
                                 monitor = validation_metric,
                                 save_best_only = True,
                                 save_weights_only = False,
                                 mode = 'max',
                                 verbose = 1
                                 )

# Save loss history
class LossHistory(Callback):
    def on_train_begin(self, logs={}):
        self.losses = []
        self.accuracy = []
        if output_num > 1:
            self.auc = []
    def on_batch_end(self, batch, logs={}):
        self.losses.append(logs.get('loss'))
        self.accuracy.append(logs.get('acc'))
        if output_num >1:
            self.auc.append(logs.get('AUC'))

loss_history = LossHistory()
reduce_lr = ReduceLROnPlateau(monitor=validation_metric, factor = 0.1, patience=3, mode='max', min_lr = 0.001)

callbacks_list = [save_snapshots, loss_history, reduce_lr]
# define train data generator
train_datagen = ImageDataGenerator()

train_generator = train_datagen.flow_from_directory(
            args['train'],
            target_size=(32, 32),
            batch_size=batch_size,
            class_mode=class_mode,
            color_mode='rgb',
            shuffle=True
            )

test_generator = train_datagen.flow_from_directory(
            args['test'],
            target_size=(32, 32),
            batch_size=batch_size,
            class_mode=class_mode,
            color_mode='rgb',
            shuffle=False
            )

epochs = args["epochs"]
steps_per_epoch = int(train_generator.samples//batch_size)
validation_steps = int(test_generator.samples//batch_size)

# train model
my_model.fit_generator(
    generator = train_generator,
    steps_per_epoch = steps_per_epoch,
    epochs = epochs,
    verbose = 1,
    callbacks = callbacks_list,
    validation_data = test_generator,
    validation_steps = validation_steps
    )
