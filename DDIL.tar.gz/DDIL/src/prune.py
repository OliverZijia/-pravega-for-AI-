import numpy as np
import tensorflow as tf
from tensorflow_model_optimization.sparsity import keras as sparsity
import sys
from tensorflow.python.keras import backend as K
from tensorflow.python.keras.utils.generic_utils import custom_object_scope
import os 
import argparse
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import tempfile
from keras.optimizers import Adam

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

ap = argparse.ArgumentParser()

ap.add_argument("-t", "--train", required=True,
                help="path to the train image directory")
ap.add_argument("-test", "--test", required=True,
                help="path to the train image directory")
ap.add_argument("-m", "--model", required=True,
                help="path to the pretrained model")
ap.add_argument("-e", "--epochs",
                type=int, default = 5,
                help="number of epochs")
ap.add_argument("-b", "--batch_size",
                type=int, default = 32,
                help="batch size")
ap.add_argument("-c", "--class_mode", required=True,
                type=str, default = 'binary',
                help="class mode")
args = vars(ap.parse_args())

batch_size = args['batch_size']
model_path = args['model']
epochs = args['epochs']
class_mode = args['class_mode']
metric = 'AUC'
loss = tf.keras.losses.binary_crossentropy
if class_mode == 'categorical':
    metric = 'accuracy'
    loss = tf.keras.losses.categorical_crossentropy
def relu6(x):
    return K.relu(x, max_value = 6)

with custom_object_scope({'relu6': relu6}):
    loaded_model = tf.keras.models.load_model(model_path)
    train_datagen = ImageDataGenerator()

    train_generator = train_datagen.flow_from_directory(
            args['train'],
            target_size = (256, 256),
            batch_size = batch_size,
            class_mode = class_mode,
            color_mode = 'grayscale',
            shuffle = True
            )

    test_generator = train_datagen.flow_from_directory(
            args['test'],
            target_size = (256, 256),
            batch_size = batch_size,
            class_mode = class_mode,
            color_mode = 'grayscale',
            shuffle = False
            )

    steps_per_epoch = int(train_generator.samples//batch_size)
    validation_steps = int(test_generator.samples//batch_size)
    
    end_step = np.ceil(1.0 * train_generator.samples / batch_size).astype(np.int32) * epochs

    pruning_schedule = sparsity.PolynomialDecay(
            initial_sparsity = 0.0,
            final_sparsity = 0.5,
            begin_step = 0,
            end_step = end_step
            )

    new_pruned_model = sparsity.prune_low_magnitude(loaded_model, pruning_schedule = pruning_schedule)

    new_pruned_model.compile(
        loss = loss,
        optimizer=Adam(0.0001),
        metrics=[metric]
        )
    
    callbacks = [sparsity.UpdatePruningStep()]

    new_pruned_model.fit_generator(
        generator = train_generator,
        steps_per_epoch = steps_per_epoch,
        epochs = epochs,
        verbose = 1,
        callbacks = callbacks,
        validation_data = test_generator,
        validation_steps = validation_steps
        )
    
    score = new_pruned_model.evaluate_generator(test_generator, validation_steps)
    print('Test loss:', score[0])
    print('Test metric:', score[1])

    final_model = sparsity.strip_pruning(new_pruned_model)
    pruned_model_path = 'pruned_' + model_path
    tf.keras.models.save_model(final_model, pruned_model_path, include_optimizer = False)
    
